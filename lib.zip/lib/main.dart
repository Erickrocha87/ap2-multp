import 'package:flutter/material.dart';

import 'theme.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Meu Destino',
      debugShowCheckedModeBanner: false,
      theme: appTheme,
      home: const PaginaDestino(),
    );
  }
}

class PaginaDestino extends StatelessWidget {
  const PaginaDestino({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meu Destino')),
      body: ListView(
        children: [
          Image.network(
            'https://picsum.photos/600/240',
            width: double.infinity,
            height: 240,
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) => Container(
              height: 240,
              color: const Color(0xFFB2DFDB),
              child: const Icon(Icons.landscape, size: 64),
            ),
          ),
          const SecaoTitulo(),
          const Divider(indent: 24, endIndent: 24),
          const SecaoBotoes(),
          const Divider(indent: 24, endIndent: 24),
          const SecaoTexto(),
        ],
      ),
    );
  }
}

class SecaoTitulo extends StatelessWidget {
  const SecaoTitulo({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Lago Oeschinen',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const SizedBox(height: 4),
                Text(
                  'Kandersteg, Suíça',
                  style: TextStyle(color: Colors.grey[600]),
                ),
              ],
            ),
          ),
          Icon(Icons.star, color: Colors.red[600]),
          const SizedBox(width: 4),
          const Text('41'),
        ],
      ),
    );
  }
}

class SecaoBotoes extends StatelessWidget {
  const SecaoBotoes({super.key});

  @override
  Widget build(BuildContext context) {
    final cor = Theme.of(context).colorScheme.primary;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          _botao(cor, Icons.call, 'LIGAR'),
          _botao(cor, Icons.near_me, 'ROTA'),
          _botao(cor, Icons.share, 'COMPARTILHAR'),
        ],
      ),
    );
  }

  Widget _botao(Color cor, IconData icone, String rotulo) {
    return TextButton(
      onPressed: () {},
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icone, color: cor),
          const SizedBox(height: 8),
          Text(
            rotulo,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: cor,
            ),
          ),
        ],
      ),
    );
  }
}

class SecaoTexto extends StatelessWidget {
  const SecaoTexto({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Text(
        'O Lago Oeschinen fica aos pés do Blüemlisalp, nos Alpes suíços. '
        'Cercado de montanhas e florestas, é um dos destinos mais visitados '
        'da região de Kandersteg.',
        softWrap: true,
        style: Theme.of(context)
            .textTheme
            .bodyMedium
            ?.copyWith(color: Colors.grey[700]),
      ),
    );
  }
}
